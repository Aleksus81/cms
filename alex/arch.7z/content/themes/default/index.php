<?php $this->theme->header(); ?>
Index Template <?= $name ?><br>
<?php $this->theme->footer(); ?>

<?php //$this->theme->sidebar(); ?>
<?php //$this->theme->component(); ?>
<?php //$this->theme->block('comments', ['comments' => '$comments']); ?>
