<?php
namespace Admin\Controller;
class PostController
{
  
}

?>