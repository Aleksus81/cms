<?php
namespace Admin\Controller;
class ErrorController extends AdminController
{
  
        public function page404()
    
    {
        echo '404 Page, а я контроллер из окружения admin<br>';
        
        
        
    }
    
    
}

?>
