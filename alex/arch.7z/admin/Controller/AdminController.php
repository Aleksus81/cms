<?php
namespace Admin\Controller;
use Engine\Controller;
class AdminController extends Controller
{
    public function __construct($di)
    
    {
        parent::__construct($di);
    }
    
}

?>