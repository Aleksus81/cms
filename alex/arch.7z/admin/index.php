<?php

//define('ROOT_DIR', __DIR__);
define('ENV', 'Admin');
require_once '../engine/bootstrap.php';
//require_once(realpath('../engine/bootstrap.php'));

echo 'а я index.php из admin';

?>