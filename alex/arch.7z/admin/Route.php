<?php

$this->router->add('login', '/admin/login', 'LoginController:form');


    echo 'привет, я роут из окружения admin<br>';

?>