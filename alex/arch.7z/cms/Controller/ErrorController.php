<?php
namespace Cms\Controller;
class ErrorController extends CmsController
{
  
        public function page404()
    
    {
        echo '404 Page, я контролер из cms';
    }
    
    
}
?>
