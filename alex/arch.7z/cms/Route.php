<?php

    $this->router->add('home', '/', 'HomeController:index');
    //$this->router->add('login', '/admin/login', 'LoginController:form');
    

?>

