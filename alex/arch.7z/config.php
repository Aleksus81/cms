<?php
 return [
     'host' => 'localhost',
     'db_name' => 'test_pdo',
     'username' => 'root',
     'password' => 'ubuntu',
     'charset' => 'utf8'

	];

?>
