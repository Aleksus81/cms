<?php

return[

	Engine\Sevice\Database\Provider::class,
	Engine\Sevice\Router\Provider::class,
	Engine\Sevice\View\Provider::class

];
?>
